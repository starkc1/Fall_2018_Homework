Extract the contents of the folder.
Open the "index.html" in a browser, leaving the file in the same directory as the "angular.min.js" file